// This is yet another example
window.hello = 'hello';